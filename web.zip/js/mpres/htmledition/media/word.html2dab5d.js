define("tpl/media/word.html.js",[],function(){
return'<!--群发消息-已发送页面文字模板-->\n<div class="appmsgSendedItem textmsg">\n    <div class="title_wrp">\n        <span class="icon" ></span>\n        <span class="title">[文字]{=content}</span>\n    </div>\n</div>\n';
});