define("statistics/article/detail/detail/multimedia/state.js",[],function(){
"use strict";
return{};
});