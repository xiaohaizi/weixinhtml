define("tpl/verifycode.html.js",[],function(){
return'<div class="verifycode">\n	<span class="frm_input_box"><input id="imgcode" name="imgcode" type="text" value="" class="frm_input"></span>\n    <div class="verifyimg_wrp">\n        <img src="">\n        <a href="javascript:;" class="changeVerifyCode">换一张</a>\n    </div>\n</div>\n';
});