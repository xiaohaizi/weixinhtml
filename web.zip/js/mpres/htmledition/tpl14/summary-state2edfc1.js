define("statistics/webpage-stat/summary/summary-state.js",[],function(){
"use strict";
return{};
});