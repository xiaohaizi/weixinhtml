define("statistics/menu_stat/summary/summary-state.js",[],function(){
"use strict";
return{};
});